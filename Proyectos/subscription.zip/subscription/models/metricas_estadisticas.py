# -*- coding: utf-8 -*-

from odoo import models, fields, api #type:ignore


class metricas_estadisticas(models.Model):
    _name = 'subscription.metricas_estadisticas'
    _description = 'subscription.metricas_estadisticas'

    fecha = fields.Date(required=True, string="Fecha de Métricas")
    suscripciones_activas = fields.Integer(string="Suscripciones Activas")
    ingresos_generados = fields.Float(string="Ingresos Generados")
    tasa_renovacion = fields.Float(compute='_compute_tasa_renovacion', store=True, string="Tasa de Renovación")
    tasa_cancelacion = fields.Float(compute='_compute_tasa_cancelacion', store=True, string="Tasa de Cancelación")
    renovaciones = fields.Integer(string="Renovaciones")
    nuevas_suscripciones = fields.Integer(string="Nuevas Suscripciones")
    suscripciones_canceladas = fields.Integer(string="Suscripciones Canceladas")
    clientes_recurrentes = fields.Integer(string="Clientes Recurrentes")
    clientes_nuevos = fields.Integer(string="Clientes Nuevos")
    arpu = fields.Float(compute='_compute_arpu', store=True, string="ARPU")
    tasa_conversion = fields.Float(string="Tasa de Conversión")
    churn_rate = fields.Float(compute='_compute_churn_rate', store=True, string="Tasa de Perdida de Clientes")
    ltv = fields.Float(string="Valor Generado por el Cliente")
    cac = fields.Float(string="Costo de Adquisición de Cliente")
    notas = fields.Text(string="Notas")
    subscription_ids = fields.One2many(comodel_name='subscription.subscription', inverse_name='metrica_id', string="Suscripciones")

    @api.depends('renovaciones', 'suscripciones_activas')
    def _compute_tasa_renovacion(self):
        for record in self:
            if record.suscripciones_activas:
                record.tasa_renovacion = (float(record.renovaciones) * 100) / float(record.suscripciones_activas)
            else:
                record.tasa_renovacion = 0.0

    @api.depends('suscripciones_canceladas', 'suscripciones_activas')
    def _compute_tasa_cancelacion(self):
        for record in self:
            if record.suscripciones_activas:
                record.tasa_cancelacion = (float(record.suscripciones_canceladas) * 100) / float(record.suscripciones_activas)
            else:
                record.tasa_cancelacion = 0.0

    @api.depends('ingresos_generados', 'suscripciones_activas')
    def _compute_arpu(self):
        for record in self:
            if record.suscripciones_activas:
                record.arpu = record.ingresos_generados / float(record.suscripciones_activas)
            else:
                record.arpu = 0.0

    @api.depends('suscripciones_canceladas', 'suscripciones_activas')
    def _compute_churn_rate(self):
        for record in self:
            if record.suscripciones_activas:
                record.churn_rate = (float(record.suscripciones_canceladas) * 100) / float(record.suscripciones_activas)
            else:
                record.churn_rate = 0.0