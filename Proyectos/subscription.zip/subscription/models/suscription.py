# -*- coding: utf-8 -*-

from odoo import models, fields, api #type:ignore
from datetime import timedelta


class subscription(models.Model):
    _name = 'subscription.subscription'
    _description = 'subscription.subscription'
    _sql_restricctions = [
        ('unique_subscription_code', 'unique(subscription_code)', 'El codigo de suscripcion ya esta en uso')
    ]

    name = fields.Char(required=True, string="Nombre")
    customer_id = fields.Many2one(comodel_name='res.partner', required=True, string="Cliente")
    subscription_code = fields.Char(required=True, string="Código de Suscripción")
    start_date = fields.Date(required=True, string="Fecha de Inicio")
    end_date = fields.Date(required=True, string="Fecha de Fin")
    renewal_date = fields.Date(required=True, string="Fecha de Renovación")
    status = fields.Selection([('active', 'Activo'), ('expired', 'Expirado'), ('pending', 'Pendiente'), ('cancelled', 'Cancelado')], required=True, string="Estado")
    is_renewable = fields.Boolean(required=True, string="Es Renovable")
    auto_renewal = fields.Boolean(required=True, string="Renovación Automática")
    price = fields.Float(required=True, string="Precio")
    usage_limit = fields.Integer(string="Límite de Uso")
    current_usage = fields.Integer(string="Uso Actual")
    use_percent = fields.Float(compute='_compute_use_percent', store=True, string="Porcentaje de Uso")
    metrica_id = fields.Many2one(comodel_name='subscription.metricas_estadisticas', string="Métrica Asociada")
            
    @api.depends('current_usage', 'usage_limit')
    def _compute_use_percent(self):
        for record in self:
            if record.usage_limit is 0 or record.current_usage is 0:
                record.use_percent = 0
            else:
                record.use_percent = (float(record.current_usage) * 100)/float(record.usage_limit)
                
    def add_days(self):
        for record in self:
            record.end_date = record.end_date + timedelta(days=15)